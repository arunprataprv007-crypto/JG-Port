/**
 * Vercel Serverless Function: POST /api/contact
 * Receives the website contact form and emails it to you via Resend.
 *
 * Environment variables (set in Vercel > Project > Settings > Environment Variables):
 *   RESEND_API_KEY     required  your Resend API key (starts with "re_")
 *   CONTACT_TO_EMAIL   required  the inbox that should receive messages
 *   CONTACT_FROM_EMAIL optional  defaults to "Portfolio <onboarding@resend.dev>"
 */

const hits = new Map(); // best-effort rate limit (resets when the function cold-starts)
const WINDOW_MS = 10 * 60 * 1000;
const MAX_HITS = 5;

const esc = (s) =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const clean = (s, max) => String(s || '').replace(/[\u0000-\u001F\u007F]/g, ' ').trim().slice(0, max);

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');

  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ ok: false, error: 'Method not allowed' });
  }

  // Rate limit by IP
  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  if (recent.length >= MAX_HITS) {
    return res.status(429).json({ ok: false, error: 'Too many messages. Please try again later.' });
  }
  recent.push(now);
  hits.set(ip, recent);

  // Body (Vercel parses JSON automatically; handle a raw string just in case)
  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch { body = {}; }
  }
  body = body || {};

  // Honeypot: real visitors never fill this hidden field
  if (body.company) return res.status(200).json({ ok: true });

  const name = clean(body.name, 100);
  const email = clean(body.email, 200);
  const topic = clean(body.topic, 100) || 'General enquiry';
  const message = String(body.message || '').replace(/\r/g, '').trim().slice(0, 3000);

  if (name.length < 2) return res.status(400).json({ ok: false, error: 'Please enter your name.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return res.status(400).json({ ok: false, error: 'Please enter a valid email.' });
  if (message.length < 10) return res.status(400).json({ ok: false, error: 'Please write a slightly longer message.' });

  const apiKey = process.env.RESEND_API_KEY;
  const to = process.env.CONTACT_TO_EMAIL;
  const from = process.env.CONTACT_FROM_EMAIL || 'Portfolio <onboarding@resend.dev>';

  if (!apiKey || !to) {
    console.error('Missing RESEND_API_KEY or CONTACT_TO_EMAIL environment variable');
    return res.status(500).json({ ok: false, error: 'Contact service is not configured yet.' });
  }

  const html = `
    <div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.6;color:#111">
      <h2 style="margin:0 0 12px">New message from your website</h2>
      <p><strong>Name:</strong> ${esc(name)}<br>
         <strong>Email:</strong> ${esc(email)}<br>
         <strong>Topic:</strong> ${esc(topic)}</p>
      <p style="white-space:pre-wrap;border-left:3px solid #b8f21c;padding-left:12px">${esc(message)}</p>
    </div>`;

  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from,
        to: [to],
        reply_to: email,
        subject: `Website enquiry: ${topic} (${name})`,
        html,
        text: `Name: ${name}\nEmail: ${email}\nTopic: ${topic}\n\n${message}`,
      }),
    });

    if (!r.ok) {
      console.error('Resend error', r.status, await r.text());
      return res.status(502).json({ ok: false, error: 'Could not send your message right now.' });
    }
    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error('Send failed', err);
    return res.status(500).json({ ok: false, error: 'Something went wrong. Please try again.' });
  }
};
