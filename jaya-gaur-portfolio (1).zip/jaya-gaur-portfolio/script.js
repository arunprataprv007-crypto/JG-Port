/* Jaya Gaur | Portfolio interactions */
(function () {
  'use strict';

  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  $('#year').textContent = new Date().getFullYear();

  /* ---------- nav: scrolled state, progress bar, mobile menu ---------- */
  var nav = $('#nav');
  var progress = $('#progress');
  var toggle = $('#navToggle');

  function onScroll() {
    var y = window.scrollY;
    var h = document.documentElement.scrollHeight - window.innerHeight;
    nav.classList.toggle('scrolled', y > 20);
    progress.style.transform = 'scaleX(' + (h > 0 ? y / h : 0) + ')';
    updateTimeline();
  }

  toggle.addEventListener('click', function () {
    var open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open);
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  });
  $$('#navLinks a').forEach(function (a) {
    a.addEventListener('click', function () {
      nav.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
    });
  });

  /* active link highlight */
  var links = $$('#navLinks a');
  var sections = links.map(function (a) { return $(a.getAttribute('href')); }).filter(Boolean);
  if ('IntersectionObserver' in window) {
    var navObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          links.forEach(function (a) {
            a.classList.toggle('active', a.getAttribute('href') === '#' + e.target.id);
          });
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    sections.forEach(function (s) { navObs.observe(s); });
  }

  /* ---------- rotating headline phrase ---------- */
  var words = $$('#rotator > span');
  var idx = 0;
  if (words.length && !reduce) {
    setInterval(function () {
      var cur = words[idx];
      cur.classList.remove('is-on');
      cur.classList.add('is-off');
      idx = (idx + 1) % words.length;
      var next = words[idx];
      next.classList.remove('is-off');
      void next.offsetWidth;
      next.classList.add('is-on');
      setTimeout(function () { cur.classList.remove('is-off'); }, 700);
    }, 2800);
  }

  /* ---------- reveal on scroll ---------- */
  var reveals = $$('.reveal');
  if ('IntersectionObserver' in window && !reduce) {
    var rObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('in'); rObs.unobserve(e.target); }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
    reveals.forEach(function (el) { rObs.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add('in'); });
  }

  /* ---------- count-up numbers ---------- */
  function countUp(el) {
    var to = parseFloat(el.dataset.to) || 0;
    var suffix = el.dataset.suffix || '';
    var prefix = el.dataset.prefix || '';
    if (reduce || to === 0) { el.textContent = prefix + to + suffix; return; }
    var dur = 1600, start = null;
    function step(ts) {
      if (!start) start = ts;
      var p = Math.min((ts - start) / dur, 1);
      var eased = 1 - Math.pow(1 - p, 4);
      el.textContent = prefix + Math.round(to * eased) + suffix;
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  var counters = $$('.count');
  if ('IntersectionObserver' in window) {
    var cObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { countUp(e.target); cObs.unobserve(e.target); }
      });
    }, { threshold: 0.6 });
    counters.forEach(function (c) { cObs.observe(c); });
  } else { counters.forEach(countUp); }

  /* ---------- process steps line ---------- */
  var steps = $('#steps');
  if (steps && 'IntersectionObserver' in window) {
    var sObs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          steps.classList.add('run');
          steps.style.setProperty('--p', 1);
          sObs.disconnect();
        }
      });
    }, { threshold: 0.35 });
    sObs.observe(steps);
  } else if (steps) { steps.classList.add('run'); steps.style.setProperty('--p', 1); }

  /* ---------- timeline fill follows scroll ---------- */
  var timeline = $('#timeline');
  function updateTimeline() {
    if (!timeline) return;
    var r = timeline.getBoundingClientRect();
    var vh = window.innerHeight;
    var p = (vh * 0.6 - r.top) / r.height;
    timeline.style.setProperty('--tl', Math.max(0, Math.min(1, p)));
  }

  /* ---------- experience accordion ---------- */
  $$('.exp-head').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var card = btn.closest('.exp');
      var open = card.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', open);
      setTimeout(updateTimeline, 600);
    });
  });

  /* ---------- spotlight on cards ---------- */
  $$('.spot').forEach(function (el) {
    el.addEventListener('pointermove', function (e) {
      var r = el.getBoundingClientRect();
      el.style.setProperty('--mx', (e.clientX - r.left) + 'px');
      el.style.setProperty('--my', (e.clientY - r.top) + 'px');
    });
  });

  /* ---------- pointer effects (desktop only) ---------- */
  if (finePointer && !reduce) {
    /* page-wide soft lime glow follows the cursor */
    var glow = $('.cursor-glow');
    var gx = 0, gy = 0, tx = 0, ty = 0, raf = null;
    window.addEventListener('pointermove', function (e) {
      tx = e.clientX; ty = e.clientY;
      glow.classList.add('on');
      if (!raf) raf = requestAnimationFrame(loop);
    });
    document.addEventListener('mouseleave', function () { glow.classList.remove('on'); });
    function loop() {
      gx += (tx - gx) * 0.12; gy += (ty - gy) * 0.12;
      glow.style.transform = 'translate3d(' + gx + 'px,' + gy + 'px,0)';
      raf = (Math.abs(tx - gx) > 0.5 || Math.abs(ty - gy) > 0.5) ? requestAnimationFrame(loop) : null;
    }

    /* 3D tilt on portrait */
    var portrait = $('#portrait'), pCard = $('#portraitCard');
    portrait.addEventListener('pointermove', function (e) {
      var r = portrait.getBoundingClientRect();
      var x = (e.clientX - r.left) / r.width - 0.5;
      var y = (e.clientY - r.top) / r.height - 0.5;
      pCard.style.transform = 'rotateY(' + (x * 10) + 'deg) rotateX(' + (-y * 10) + 'deg)';
    });
    portrait.addEventListener('pointerleave', function () { pCard.style.transform = ''; });

    /* magnetic buttons */
    $$('.magnetic').forEach(function (b) {
      b.addEventListener('pointermove', function (e) {
        var r = b.getBoundingClientRect();
        var x = e.clientX - (r.left + r.width / 2);
        var y = e.clientY - (r.top + r.height / 2);
        b.style.transform = 'translate(' + (x * 0.18) + 'px,' + (y * 0.25) + 'px)';
      });
      b.addEventListener('pointerleave', function () { b.style.transform = ''; });
    });
  }

  /* ---------- Boolean search typing demo ---------- */
  var demo = $('#searchDemo'), out = $('#searchText');
  var query = '("multi-skilled engineer" OR millwright) AND (PLC OR "fault finding") AND (food OR FMCG)';
  if (demo && out) {
    if (reduce) { out.textContent = query; demo.classList.add('done'); }
    else if ('IntersectionObserver' in window) {
      var dObs = new IntersectionObserver(function (entries) {
        if (entries[0].isIntersecting) { dObs.disconnect(); typeLoop(); }
      }, { threshold: 0.5 });
      dObs.observe(demo);
    } else { out.textContent = query; demo.classList.add('done'); }
  }
  function typeLoop() {
    var i = 0;
    out.textContent = '';
    demo.classList.remove('done');
    (function tick() {
      if (i <= query.length) {
        out.textContent = query.slice(0, i++);
        setTimeout(tick, 28 + Math.random() * 30);
      } else {
        demo.classList.add('done');
        setTimeout(typeLoop, 6500);
      }
    })();
  }

  /* ---------- markets tabs ---------- */
  var tabs = $$('.m-tabs [role="tab"]');
  function selectTab(t) {
    tabs.forEach(function (x) {
      var on = x === t;
      x.setAttribute('aria-selected', on);
      x.tabIndex = on ? 0 : -1;
      var p = document.getElementById(x.getAttribute('aria-controls'));
      p.hidden = !on; p.classList.toggle('is-on', on);
    });
    t.focus();
  }
  tabs.forEach(function (t, i) {
    t.addEventListener('click', function () { selectTab(t); });
    t.addEventListener('keydown', function (e) {
      var n = e.key === 'ArrowDown' || e.key === 'ArrowRight' ? 1 : e.key === 'ArrowUp' || e.key === 'ArrowLeft' ? -1 : 0;
      if (n) { e.preventDefault(); selectTab(tabs[(i + n + tabs.length) % tabs.length]); }
    });
  });

  /* ---------- show Download CV only if the PDF exists ---------- */
  var cvBtn = $('#cvBtn');
  if (cvBtn && window.fetch) {
    fetch(cvBtn.getAttribute('href'), { method: 'HEAD' }).then(function (r) {
      var type = r.headers.get('content-type') || '';
      if (r.ok && type.indexOf('pdf') > -1) cvBtn.hidden = false;
    }).catch(function () {});
  }

  /* ---------- contact form -> /api/contact ---------- */
  var form = $('#contactForm');
  var statusEl = $('#formStatus');
  var submitBtn = $('#submitBtn');
  var FALLBACK_EMAIL = 'jjaya.gaur@work-force.co.uk';

  function setStatus(msg, type, html) {
    statusEl.className = 'form-status ' + (type || '');
    if (html) statusEl.innerHTML = msg; else statusEl.textContent = msg;
  }
  function validEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v); }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var data = {
      name: form.name.value.trim(),
      email: form.email.value.trim(),
      topic: form.topic.value,
      message: form.message.value.trim(),
      organisation: form.organisation.value.trim(),
      company: form.company.value
    };

    var ok = true;
    [['name', data.name.length >= 2], ['email', validEmail(data.email)], ['message', data.message.length >= 10]].forEach(function (c) {
      var field = form[c[0]].closest('.field');
      field.classList.toggle('invalid', !c[1]);
      if (!c[1]) ok = false;
    });
    if (!ok) { setStatus('Please check your name, a valid email and a message of at least 10 characters.', 'err'); return; }

    submitBtn.classList.add('loading');
    setStatus('Sending...', '');

    fetch('/api/contact', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
      .then(function (res) { return res.json().catch(function () { return {}; }).then(function (j) { return { ok: res.ok, body: j }; }); })
      .then(function (r) {
        if (!r.ok) throw new Error(r.body.error || 'Request failed');
        form.reset();
        setStatus('Thank you. Your message is on its way and I will reply soon.', 'ok');
      })
      .catch(function () {
        setStatus('Sorry, that did not send. Please email me directly at <a href="mailto:' + FALLBACK_EMAIL + '">' + FALLBACK_EMAIL + '</a>.', 'err', true);
      })
      .then(function () { submitBtn.classList.remove('loading'); });
  });

  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', onScroll);
  onScroll();
})();
