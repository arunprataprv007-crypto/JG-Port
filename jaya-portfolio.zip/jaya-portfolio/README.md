# Jaya Gaur: personal CV website

Static frontend (`index.html`, `styles.css`, `script.js`) plus one Vercel serverless
function (`api/contact.js`) that emails contact-form messages through Resend.

```
index.html        the page (edit text here; placeholders are in [square brackets])
styles.css        styling and the one page-load animation
script.js         menu, photo fallback, CV button check, contact form
favicon.svg       browser tab icon
assets/           add jaya.jpg here (and optionally Jaya_Gaur_CV.pdf)
api/contact.js    backend: POST /api/contact -> Resend -> your inbox
vercel.json       security headers and caching
package.json      tells Vercel to use Node 18+ and ES modules
.env.example      the two variables to set in Vercel
.gitignore        keeps .env and .vercel out of GitHub
```

## Deploy from GitHub

1. Get a Resend API key (https://resend.com > API Keys > Create, "Sending access").
2. Create a GitHub repo `jaya-portfolio`, click **uploading an existing file**, and drag in
   everything from this folder, including `api/`, `assets/`, `.gitignore` and `vercel.json`.
   `index.html` must sit at the top level of the repo. Commit.
   (Hidden files like `.gitignore` may not show in Finder/Explorer; it's fine if they're skipped.)
3. Add your photo as `assets/jaya.jpg` (4:5 portrait works best). Until then the page shows "JG".
4. On https://vercel.com: **Add New > Project > Import** `jaya-portfolio`.
   Framework Preset **Other**, leave Build Command and Output Directory empty.
5. Environment Variables:
   - `RESEND_API_KEY` = your `re_...` key
   - `CONTACT_TO_EMAIL` = the email you signed up to Resend with
6. **Deploy**, open the live link, send a test message.

Every commit to the `main` branch redeploys automatically. Changing environment variables
needs a manual **Redeploy**.

## Before going public

- Replace every `[placeholder]` in `index.html`.
- The email in `index.html` and `script.js` (`FALLBACK_EMAIL`) is your work address. Consider a
  personal one; also double-check the spelling (`jjaya.gaur@...`).
- The CV button appears only when `assets/Jaya_Gaur_CV.pdf` exists. Remove your phone number
  and the internal footer from the PDF first.
- Once you know your URL, add `og:image` in `<head>` (see the comment there).

## Local preview

`npm i -g vercel` then `vercel dev` and open http://localhost:3000 (the form needs this or the
live site; double-clicking `index.html` shows the design only).
