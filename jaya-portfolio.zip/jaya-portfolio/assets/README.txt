Put jaya.jpg (4:5 portrait) and optionally Jaya_Gaur_CV.pdf here.
