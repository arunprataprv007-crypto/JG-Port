// EDIT: keep in sync with the email shown in index.html
const FALLBACK_EMAIL = "jjaya.gaur@work-force.co.uk";
const CV_PATH = "assets/Jaya_Gaur_CV.pdf";

document.addEventListener("DOMContentLoaded", () => {
  // Footer year
  const year = document.getElementById("year");
  if (year) year.textContent = String(new Date().getFullYear());

  // Keep the visible email in sync with FALLBACK_EMAIL
  const emailLink = document.getElementById("contact-email");
  if (emailLink) {
    emailLink.href = `mailto:${FALLBACK_EMAIL}`;
    emailLink.textContent = FALLBACK_EMAIL;
  }

  setUpNav();
  setUpPhotoFallback();
  showCvButtonIfPresent();
  setUpContactForm();
});

function setUpNav() {
  const toggle = document.querySelector(".nav-toggle");
  const nav = document.getElementById("site-nav");
  if (!toggle || !nav) return;

  const close = () => {
    nav.classList.remove("is-open");
    toggle.setAttribute("aria-expanded", "false");
    toggle.textContent = "Menu";
  };

  toggle.addEventListener("click", () => {
    const open = !nav.classList.contains("is-open");
    nav.classList.toggle("is-open", open);
    toggle.setAttribute("aria-expanded", String(open));
    toggle.textContent = open ? "Close" : "Menu";
  });
  nav.addEventListener("click", (e) => { if (e.target.closest("a")) close(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
}

// If assets/jaya.jpg is missing, show initials instead of a broken image
function setUpPhotoFallback() {
  const fig = document.querySelector(".hero-photo");
  const img = fig && fig.querySelector("img");
  if (!img) return;
  const markMissing = () => fig.classList.add("is-missing");
  if (img.complete && img.naturalWidth === 0) markMissing();
  img.addEventListener("error", markMissing);
}

// The CV button only appears if the PDF has been added to /assets
async function showCvButtonIfPresent() {
  const btn = document.getElementById("cv-button");
  if (!btn) return;
  try {
    const res = await fetch(CV_PATH, { method: "HEAD", cache: "no-store" });
    const type = res.headers.get("content-type") || "";
    if (res.ok && type.includes("pdf")) btn.hidden = false;
  } catch {
    /* offline or file:// preview: keep hidden */
  }
}

function setUpContactForm() {
  const form = document.getElementById("contact-form");
  if (!form) return;
  const status = document.getElementById("form-status");
  const submit = document.getElementById("cf-submit");

  const setStatus = (msg, kind) => {
    status.textContent = "";
    status.className = "form-status" + (kind ? ` is-${kind}` : "");
    if (typeof msg === "string") status.textContent = msg;
    else if (msg) status.append(msg);
  };

  const fields = {
    name: form.elements.name,
    email: form.elements.email,
    message: form.elements.message,
  };

  Object.values(fields).forEach((el) =>
    el.addEventListener("input", () => el.removeAttribute("aria-invalid"))
  );

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const data = {
      name: fields.name.value.trim(),
      email: fields.email.value.trim(),
      message: fields.message.value.trim(),
      website: form.elements.website.value, // spam trap
    };

    const problems = [];
    if (!data.name) problems.push(["name", "Add your name."]);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) problems.push(["email", "Add an email address I can reply to."]);
    if (data.message.length < 10) problems.push(["message", "Write a message of at least 10 characters."]);

    if (problems.length) {
      problems.forEach(([key]) => fields[key].setAttribute("aria-invalid", "true"));
      fields[problems[0][0]].focus();
      setStatus(problems.map((p) => p[1]).join(" "), "error");
      return;
    }

    submit.disabled = true;
    submit.textContent = "Sending...";
    setStatus("");

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok || !body.ok) throw new Error(body.error || `HTTP ${res.status}`);

      form.reset();
      setStatus("Message sent. I will reply to the email you gave.", "ok");
    } catch (err) {
      console.error("Contact form:", err);
      const frag = document.createDocumentFragment();
      frag.append("Your message did not send. Email me directly at ");
      const a = document.createElement("a");
      a.href = `mailto:${FALLBACK_EMAIL}?subject=${encodeURIComponent("Message from " + data.name)}&body=${encodeURIComponent(data.message)}`;
      a.textContent = FALLBACK_EMAIL;
      frag.append(a, ".");
      setStatus(frag, "error");
    } finally {
      submit.disabled = false;
      submit.textContent = "Send message";
    }
  });
}
